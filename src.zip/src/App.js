import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { format } from 'date-fns';

// Inline CSS styles
const styles = {
  todoListContainer: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    backgroundColor: '#f0f0f0', // Background color added
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
  },
  todoList: {
    maxWidth: '400px',
    margin: '0 auto',
  },
  input: {
    width: 'calc(100% - 70px)',
    padding: '8px',
    marginBottom: '10px',
    border: '1px solid #ccc',
    borderRadius: '3px',
  },
  button: {
    padding: '8px 15px',
    marginLeft: '10px',
    backgroundColor: '#007bff',
    color: '#fff',
    border: 'none',
    borderRadius: '3px',
    cursor: 'pointer',
  },
  ul: {
    listStyleType: 'none',
    padding: '0',
  },
  li: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    marginBottom: '5px',
  },
  deleteButton: {
    marginLeft: '10px',
    backgroundColor: '#dc3545',
    color: '#fff',
    border: 'none',
    borderRadius: '50%',
    cursor: 'pointer',
  },
  dateContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    width: '100%',
    marginTop: '5px',
  },
  datePicker: {
    width: '48%',
  },
};

function TodoList() {
  const [todos, setTodos] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [createdDate, setCreatedDate] = useState(new Date());
  const [completionDate, setCompletionDate] = useState(null);

  const addTodo = () => {
    if (inputValue.trim() !== '' && completionDate) {
      const newTodo = {
        text: inputValue,
        createdDate,
        completionDate,
      };
      setTodos([...todos, newTodo]);
      setInputValue('');
      setCreatedDate(new Date());
      setCompletionDate(null);
    }
  };

  const removeTodo = (index) => {
    const newTodos = [...todos];
    newTodos.splice(index, 1);
    setTodos(newTodos);
  };

  return (
    <div style={styles.todoListContainer}>
      <div style={styles.todoList}>
        <h2>To-Do List</h2>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Enter your task"
          style={styles.input}
        />
        <div style={styles.dateContainer}>
          <DatePicker
            selected={createdDate}
            onChange={(date) => setCreatedDate(date)}
            dateFormat="dd/MM/yyyy"
            style={styles.datePicker}
            className="date-picker"
          />
          <DatePicker
            selected={completionDate}
            onChange={(date) => setCompletionDate(date)}
            dateFormat="dd/MM/yyyy"
            placeholderText="Complete by"
            style={styles.datePicker}
            className="date-picker"
          />
        </div>
        <button onClick={addTodo} style={styles.button}>
          Add
        </button>
        <ul style={styles.ul}>
          {todos.map((todo, index) => (
            <li key={index} style={styles.li}>
              <span>{todo.text}</span>
              <span>Created on: {format(todo.createdDate, 'dd/MM/yyyy')}</span>
              <span>Complete by: {format(todo.completionDate, 'dd/MM/yyyy')}</span>
              <button onClick={() => removeTodo(index)} style={styles.deleteButton}>
                Delete
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default TodoList;
